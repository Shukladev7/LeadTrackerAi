// Firestore-based data service - replaces JSON file operations
// Original JSON-based service backed up as index-json-backup.ts

export * from '../firestore-data-service';
