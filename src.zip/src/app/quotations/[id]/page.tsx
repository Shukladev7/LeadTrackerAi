
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import {
  getQuotationById,
  getLeadById,
  getProducts,
} from '@/lib/data';
import { Button } from '@/components/ui/button';
import { QuotationPreview } from './quotation-preview';

export default async function QuotationDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const quotation = await getQuotationById(params.id);
  if (!quotation) {
    notFound();
  }

  const [lead, allProducts] = await Promise.all([
    getLeadById(quotation.leadId),
    getProducts(),
  ]);

  if (!lead) {
    notFound();
  }

  const populatedProducts = quotation.products.map((p) => {
    const product = allProducts.find((ap) => ap.id === p.productId);
    if (!product) {
      throw new Error(`Product details not found for ID: ${p.productId}`);
    }
    const amount = p.quantity * p.rate;
    const gstAmount = amount * (p.gstRate / 100);
    return { ...p, product, amount, gstAmount };
  });

  return (
    <>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/quotations">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h2 className="text-3xl font-bold tracking-tight">
            Quotation Details
          </h2>
        </div>
      </div>
      <QuotationPreview
        quotation={quotation}
        lead={lead}
        products={populatedProducts}
      />
    </>
  );
}
