
import { UserProfile } from '@/components/auth/user-profile';

export default function ProfilePage() {
  return (
    <>
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">My Profile</h2>
      </div>
      
      <UserProfile />
    </>
  );
}
